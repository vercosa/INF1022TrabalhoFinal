#include <stdio.h>

int main(void) {
	int X = 0;
	int Z;

	if(X){
		Z=X;
	Z=0;

	}
	Z++;

	printf("%s",Z);
	return 0;
}