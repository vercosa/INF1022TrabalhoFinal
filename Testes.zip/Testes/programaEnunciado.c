#include <stdio.h>

int main(void) {
	int X = 0, Y = 0;
	int Z;

	Z=Y;
	while (X) {
		Z++;
	}

	printf("%s",Z);
	return 0;
}